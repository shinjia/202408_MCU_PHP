# drag_upload

- v1 一種寫法
- v2 另一種寫法
